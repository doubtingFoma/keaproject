﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Black_Exercise_05_01
{
    class Customer
    {
        //this is a simple string property for the whole class
        public string username;

        //These are just other examples of properties:
        public int age;
        public bool alive;
        public float weight;
        //you can use these properties for every customer type variable
    }
}
