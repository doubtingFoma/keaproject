﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Black_Exercise_05_03
{
    class Item
    {
        //Just a simple item that has a name and a price
        public string Name;
        //yes, i used a float, because eg: 39.99 DKK 
        public float Price;

    }
}
