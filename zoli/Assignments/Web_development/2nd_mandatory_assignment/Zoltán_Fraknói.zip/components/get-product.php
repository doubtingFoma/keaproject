<?php
  
  $sProducts = file_get_contents("products.json");
  //$aProducts = json_decode($sProducts);

  echo $sProducts;

?>
