<table class="table table-striped" id="tblProducts" class="dataTable">
    <thead>
      <tr>
        <th>Name</th>
        <th>Price</th>
      </tr>
    </thead>
    <tbody id="tblProductList">
    </tbody>
  </table>
